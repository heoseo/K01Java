
public class HelloWorld {

	public static void main(String[] args) {

		System.out.println("Hello Wordld..!!");
		System.out.println("안뇽??  Java..!!");
		System.out.println("코로나19  물러가라..!!");
	}

}
