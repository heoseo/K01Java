package ex02variable;

public class Qu_02_01 {

	public static void main(String[] args) {

		int kor = 89;
		int eng = 99;
		int math = 78;
		int sum;
		
		sum = kor + eng + math;
		
		System.out.printf("국어 : %d, 영어 : %d, 수학 : %d\n", kor, eng, math);
		System.out.println("총점 : " + sum);
		
	}

}
