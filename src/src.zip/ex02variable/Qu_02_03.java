package ex02variable;

public class Qu_02_03 {

	public static void main(String[] args) {
		
		int r = 10;
		final float PI = 3.14f;
		
		int area_int = (int)(r * r * PI);
		float area_float = (float)(r * r * PI);
		double area_double = (double)(r * r * PI);
		
		
		System.out.println("int형 넓이 : " + area_int);
		System.out.println("float형 넓이 : " + area_float);
		System.out.println("double형 넓이 : " + area_double);

	}

}
